import React from 'react'

const Section2 = () => {
  return (
    <div className='w-full h-screen bg-gray-500 text-white'>
      Section2
    </div>
  )
}

export default Section2
